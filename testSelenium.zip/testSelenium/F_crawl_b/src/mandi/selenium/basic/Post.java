package mandi.selenium.basic;

import java.util.concurrent.atomic.AtomicInteger;

public class Post {
	private static final AtomicInteger count = new AtomicInteger(0); 
	final long postId;
	String postContent;
	String postTime;
	String likeNr = null;
	String loveNr = null;
	String hahaNr = null;
	String WowNr = null;
	String AngryNr = null;
	String SadNr = null;
	String CurrentUrl = null;
			
	
	public Post(String postTime,String postContent,String likeNr, String loveNr, String hahaNr, String WowNr,
			String AngryNr, String SadNr,String currentUrl) {
		this.postContent = postContent;
		this.postTime = postTime;
		this.likeNr = likeNr;
		this.loveNr = loveNr;
		this.hahaNr = hahaNr;
		this.WowNr = WowNr;
		this.AngryNr = AngryNr;
		this.SadNr = SadNr;
		this.CurrentUrl = currentUrl;
		postId =  count.incrementAndGet(); 
	}
	
	public String getPostId() {
		String postID = Long.toString(postId);
		return postID;
	}
	
	public String getPostTime() {
		return postTime;
	}
	
	public void setPostTime(String postTime) {
		this.postTime = postTime;
	}

	public String getPostContent() {
		return postContent;
	}
	
	public void setPostContent(String postContent) {
		this.postContent = postContent;
	}
	
	public String getLikeNr() {
		return likeNr;
	}
	
	public void setLikeNr(String likeNr) {
		this.likeNr = likeNr;
	}
	
	public String getLoveNr() {
		return loveNr;
	}
	
	public void setLoveNr(String loveNr) {
		this.loveNr = loveNr;
	}

	public String getHahaNr() {
		return hahaNr;
	}
	
	public void setHahaNr(String hahaNr) {
		this.hahaNr = hahaNr;
	}
	
	public String getWowNr() {
		return WowNr;
	}
	
	public void setWowNr(String WowNr) {
		this.WowNr = WowNr;
	}
	
	public String getAngryNr() {
		return AngryNr;
	}
	
	public void setAngryNr(String angryNr) {
		this.AngryNr = angryNr;
	}
	
	public String getSadNr() {
		return SadNr;
	}
	
	public void setSadNr(String sadNr) {
		this.SadNr = sadNr;
	}
	
	public String getCurrentUrl() {
		return CurrentUrl;
	}
	
	public void setCurrentUrl(String currentUrl) {
		this.CurrentUrl = currentUrl;
	}
}
