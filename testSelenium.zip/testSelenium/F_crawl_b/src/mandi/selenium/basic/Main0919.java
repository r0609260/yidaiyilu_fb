package mandi.selenium.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebElement;

public class Main0919 {

	private WebDriver driver;
	private JavascriptExecutor jse;
	private List<Post> readIn = new ArrayList<Post>();
	
	private final String sheetName = "Tales of Reval";
	private final String crawlUrl = "https://mbasic.facebook.com/";
	private final int loopTime = 2;
	private final int postNrOnePage = 5;
	private final String limitYear = "2017";
	private final int limitYearInt = 2017;
	
	public void invokeBrowser() {
		try {
			System.setProperty("webdriver.chrome.driver", "F:\\mySelenium\\webdriver\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().deleteAllCookies();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			
			driver.get(crawlUrl);
			login();
			
			//get all posts
			for(int i = 0; i < loopTime; i++) {
				System.out.println("###########################"+ i +"##############################");
				getPosts();
				showMore();
			}
			
			//write to excel
			WriteToExcel write = new WriteToExcel();
			write.writeOut(readIn,sheetName);
	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void showMore() {
		driver.findElement(By.xpath("//*[@id=\"structured_composer_async_container\"]/div[2]/a\r\n")).click();
    }
	
	
	public void getFullStory() throws InterruptedException {

		WebElement eContent = null, eContent1 = null, eContent2 = null;
		
		String currentUrl = driver.getCurrentUrl();
		
		eContent2 = driver.findElement(By.xpath("//*[@id=\"u_0_0\"]/div[1]/div[2]"
				+"| //*[@id=\"u_0_1\"]/div[1]/div[2]"
				));
		
		String eContent2Text = eContent2.getText();
		
		if(eContent2Text.equals("Like\nReact\nComment\nShare")) {
			eContent1 = driver.findElement(By.xpath("//*[@id=\"MPhotoContent\"]/div[1]/div[1]/div"));
			eContent = eContent1;
		}
		else {
			eContent = eContent2;
		}
	
		String postContent = eContent.getText();	
//		System.out.println("*********postContent is**********" + postContent);
		
		WebElement eTime;
		eTime = driver.findElement(By.xpath("//*[@id=\"u_0_0\"]/div[2]/div[1]/abbr"
				+"| //*[@id=\"u_0_1\"]/div[2]/div[1]/abbr"
				+"| //*[@id=\"MPhotoContent\"]/div[1]/div[2]/span/div/div/abbr"));				
		String postTime = eTime.getText();
		
		driver.findElement(By.xpath("//div[contains(@id,'sentence_')]/a")).click();
		
		List<WebElement> expressionNr = driver.findElements
				(By.xpath("//*[@id=\"root\"]/table/tbody/tr/td/div/div/a/span"));
		
		List<String> expressionNrString = new ArrayList<String>();
		for(WebElement w : expressionNr) {
			expressionNrString.add(w.getText());
		}
		for(int i = expressionNr.size(); i < 6; i++) {
			expressionNrString.add("0");
		}

		driver.navigate().back();
		
		Post newPost = new Post(postTime,postContent,
				expressionNrString.get(0),
				expressionNrString.get(1),
				expressionNrString.get(2),
				expressionNrString.get(3),
				expressionNrString.get(4),
				expressionNrString.get(5),
				currentUrl);
		
		readIn.add(newPost);

	}
	
	
	public void getPosts() throws InterruptedException {		
		for (int i = 0; i < postNrOnePage; i++) {
			List<WebElement> posts = driver.findElements(By.xpath("//*/div[2]/div[2]/a[4]"));
			posts.get(i).click();
			getFullStory();
			driver.navigate().back();
		}
	}
	
	public void login() {
		try {
			//login
			driver.findElement(By.id("m_login_email")).sendKeys("0485629790");
			driver.findElement(By.name("pass")).sendKeys("Lmd960402");			
			//sleep for 2 seconds for the page to be loaded
			Thread.sleep(2000);
			driver.findElement(By.name("login")).click();
			
			//remember device
			driver.findElement(By.xpath("//*[@id=\"root\"]/table/tbody/tr/td/div/form/div/input")).click();	
			
			//search
			driver.findElement(By.name("query")).sendKeys(sheetName);
			Thread.sleep(1000);
			driver.findElement(By.xpath("//*[@id=\"header\"]/form/table/tbody/tr/td[3]/input")).click();
			driver.findElement(By.xpath("//*[@id=\"BrowseResultsContainer\"]/div[1]/div/div[2]/table/tbody/tr/td[2]/a\r\n")).click();

			//scroll down
//			jse = (JavascriptExecutor)driver;
//			jse.executeScript("scroll(0,1000)");
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	
	public static void main(String[] args) {
		Main0919 myObj = new Main0919();
		myObj.invokeBrowser();
	}

}
