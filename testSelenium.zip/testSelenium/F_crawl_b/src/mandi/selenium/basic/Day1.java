//package mandi.selenium.basic;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.concurrent.TimeUnit;
//
//import org.openqa.selenium.By;
//import org.openqa.selenium.JavascriptExecutor;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.WebElement;
//
//public class Day1 {
//
//	private WebDriver driver;
//	private JavascriptExecutor jse;
//	private List<Post> readIn = new ArrayList<Post>();
//	
//	private final String sheetName = "Tales of Reval";
//	private final String crawlUrl = "https://mbasic.facebook.com/";
//	private final int loopTime = 100;
//	private final String limitYear = "2017";
//	private final int limitYearInt = 2017;
//	
//	public void invokeBrowser() {
//		try {
//			System.setProperty("webdriver.chrome.driver", "F:\\mySelenium\\webdriver\\chromedriver.exe");
//			driver = new ChromeDriver();
//			driver.manage().deleteAllCookies();
//			driver.manage().window().maximize();
//			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
//			
//			driver.get(crawlUrl);
//			login();
//			
//			for(int i = 0; i < loopTime; i++) {
//				System.out.println("###########################"+ i +"##############################");
//				int postReturn = getPosts();
//				if(postReturn == limitYearInt) {
//					break;
//				}
//				showMore();
//			}
//			
//			WriteToExcel write = new WriteToExcel();
//			write.writeOut(readIn,sheetName);
//	
//			
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
//	
//	public void showMore() {
//		driver.findElement(By.xpath("//*[@id=\"structured_composer_async_container\"]/div[2]/a\r\n")).click();
//	}
//	
//	public String findPostsByXpath(String postXpath,String timeXpath) {
//		WebElement eContent;
//		eContent = driver.findElement(By.xpath(postXpath));
//		String postContent = eContent.getText();
//		
//		WebElement eTime;
//		eTime = driver.findElement(By.xpath(timeXpath));
//		String postTime = eTime.getText();
//		
//		Post newPost = new Post(postTime,postContent);
//		
//		readIn.add(newPost);
//		return postTime;
//	}
//	
//	public int getPosts() {
//		
//		int returnValue = 0;
//		
//		try {
//
//			String returnValue1 = findPostsByXpath("//*[@id=\"u_0_2\"]/div[1]/div[2]","//*[@id=\"u_0_2\"]/div[2]/div[1]/abbr\r\n");
//			String returnValue2 = findPostsByXpath("//*[@id=\"u_0_3\"]/div[1]/div[2]","//*[@id=\"u_0_3\"]/div[2]/div[1]/abbr\r\n");
//			String returnValue3 = findPostsByXpath("//*[@id=\"u_0_4\"]/div[1]/div[2]","//*[@id=\"u_0_4\"]/div[2]/div[1]/abbr\r\n");
//			String returnValue4 = findPostsByXpath("//*[@id=\"u_0_5\"]/div[1]/div[2]","//*[@id=\"u_0_5\"]/div[2]/div[1]/abbr\r\n");
//			String returnValue5 = findPostsByXpath("//*[@id=\"u_0_1\"]/div[1]/div[2] "
//					     + "| //*[@id=\"u_0_6\"]/div[1]/div[2]"
//					     + "| //*[@id=\"u_0_7\"]/div[1]/div[2]",
//					    "//*[@id=\"u_0_1\"]/div[2]/div[1]/abbr\r\n"
//					+ "| //*[@id=\"u_0_6\"]/div[2]/div[1]/abbr\r\n"
//					+ "| //*[@id=\"u_0_7\"]/div[2]/div[1]/abbr\r\n");
//			
//			
//			if( returnValue1.contains(limitYear)
//					||  returnValue2.contains(limitYear)
//					||  returnValue3.contains(limitYear)
//					||  returnValue4.contains(limitYear)
//					||  returnValue5.contains(limitYear)) {
//				returnValue = limitYearInt;				
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		
//		return returnValue;
//	}
//	
//	public void login() {
//		try {
//			driver.findElement(By.id("m_login_email")).sendKeys("0485629790");
//			driver.findElement(By.name("pass")).sendKeys("Lmd960402");
//			
//			//sleep for 2 seconds for the page to be loaded
//			Thread.sleep(2000);
//			driver.findElement(By.name("login")).click();
//			
//			driver.findElement(By.xpath("//*[@id=\"root\"]/table/tbody/tr/td/div/form/div/input")).click();
//		
//			driver.findElement(By.name("query")).sendKeys(sheetName);
//			
//			Thread.sleep(1000);
//			driver.findElement(By.xpath("//*[@id=\"header\"]/form/table/tbody/tr/td[3]/input")).click();
//			driver.findElement(By.xpath("//*[@id=\"BrowseResultsContainer\"]/div[1]/div/div[2]/table/tbody/tr/td[2]/a\r\n")).click();
//
//			//scroll down
////			jse = (JavascriptExecutor)driver;
////			jse.executeScript("scroll(0,1000)");
//			
////			List<WebElement> titleList = 
////					driver.findElements(By.xpath("//*/div[1]/div[2]/span/p")); 
//			
//			
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
//		
//	}
//	
//	public static void main(String[] args) {
//		Day1 myObj = new Day1();
//		myObj.invokeBrowser();
//		
//	}
//
//}
